#!/usr/bin/env python3
import json,re
from pathlib import Path
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'catalog.json').read_text())
assert data['count']==1008==len(data['skills'])
assert len(data['categories'])==56
assert len({s['name'] for s in data['skills']})==1008
for s in data['skills']:
    p=root/s['path']; assert p.is_file() and p.name=='SKILL.md',p
    t=p.read_text()
    assert t.startswith('---\nname: '+s['name']+'\ndescription: '),p
    assert len(t.splitlines())<500,p
    assert re.fullmatch(r'[a-z0-9-]{1,63}',s['name']),p
    assert 'CONTRACT.md' in t and s['source_anchor'] in t,p
assert set(data['categories'])=={s['category'] for s in data['skills']}
print('Validated',len(data['skills']),'unique skills across',len(data['categories']),'categories')
