#!/usr/bin/env python3
"""Offline text search; never executes a tool against a target."""
import argparse, json, re
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('query',nargs='+',help='Search terms')
p.add_argument('--limit',type=int,default=5)
a=p.parse_args()
root=Path(__file__).resolve().parents[1]
skills=json.loads((root/'catalog.json').read_text())['skills']
terms=set(re.findall(r'[a-z0-9]+',' '.join(a.query).lower()))
def score(s):
    title=set(s['name'].split('-'))
    body=set(re.findall(r'[a-z0-9]+',(s['description']+' '+s['category']).lower()))
    return 3*len(terms&title)+len(terms&body)
for s in sorted(skills,key=lambda x:(-score(x),x['name']))[:max(1,min(a.limit,20))]:
    if score(s): print(f"{score(s):2} {s['name']:45} {s['path']}")
