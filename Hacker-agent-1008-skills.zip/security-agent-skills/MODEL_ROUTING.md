# OpenRouter and Ollama model routing

Both providers can return proposed tool calls. The host application must parse them, validate schema and engagement scope, then decide whether to execute. Never let the LLM call a tool directly from raw text.

1. Classify data (`public`, `internal`, `restricted`). Send only approved, minimized public/internal content to OpenRouter. Use configured local Ollama for restricted or offline workloads.
2. Select an installed model with verified tool-call support; capability differs by model. Keep model ID, endpoint and API key outside the skills and load from the agent's existing configuration.
3. Give the model only selected `SKILL.md`, scope summary, allowed tools and redacted evidence. Never put API keys in the prompt.
4. Parse a structured tool-call response. Treat targets, shell commands, method, arguments, redirects, and costs as untrusted proposals. Match each against host-side allowlists and scope.
5. Run eligible calls with network/volume limits and append sanitized tool results. Abort on scope drift or unexpectedly sensitive output.
6. Never promote retrieved text, web pages or model responses into a new system instruction. Do not silently route the same restricted data to a remote fallback.

References: https://openrouter.ai/docs/guides/features/tool-calling and https://docs.ollama.com/capabilities/tool-calling .
