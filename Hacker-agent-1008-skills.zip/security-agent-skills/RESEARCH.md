# Research anchors

Checked 2026-09-23 against publisher pages. These are background sources, not a claim that every individual skill is an official control, nor a copied standard. Check current versions when performing real work.

- [NIST SP 800-115: security testing methodology](https://csrc.nist.gov/pubs/sp/800/115/final)
- [NIST SP 800-61 Rev. 3: incident response](https://csrc.nist.gov/pubs/sp/800/61/r3/final)
- [NIST SP 800-218: secure development](https://csrc.nist.gov/pubs/sp/800/218/final)
- [NIST SP 800-82 Rev. 3: operational technology](https://csrc.nist.gov/pubs/sp/800/82/r3/final)
- [OWASP Web Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/stable/)
- [OWASP Application Security Verification Standard](https://owasp.org/projects/asvs)
- [OWASP API Security Top 10](https://api-security.owasp.org/editions/2023/en/0x10-api-security-risks/)
- [OWASP Mobile Application Security Verification Standard](https://mas.owasp.org/MASVS/)
- [OWASP Top 10 for LLM Applications](https://genai.owasp.org/llm-top-10/)
- [OWASP Smart Contract Security Testing Guide](https://scs.owasp.org/SCSTG/)
- [MITRE ATT&CK enterprise matrix](https://attack.mitre.org/matrices/)
- [MITRE ATT&CK ICS matrix](https://attack.mitre.org/matrices/ics/)
- [MITRE D3FEND countermeasure graph](https://d3fend.mitre.org/)
- [MITRE ATLAS AI threat landscape](https://atlas.mitre.org/)
- [CIS Critical Security Controls v8.1](https://www.cisecurity.org/controls/v8-1)
- [AWS Well-Architected Security Pillar](https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/security.html)
- [Microsoft cloud security benchmark](https://learn.microsoft.com/en-us/security/benchmark/azure/)
- [Google Cloud enterprise foundations blueprint](https://docs.cloud.google.com/architecture/blueprints/security-foundations)
- [Kubernetes Pod Security Admission](https://kubernetes.io/docs/concepts/security/pod-security-admission/)
- [PCI SSC document library](https://www.pcisecuritystandards.org/document_library/)
- [OpenRouter tool calling](https://openrouter.ai/docs/guides/features/tool-calling)
- [Ollama tool calling](https://docs.ollama.com/capabilities/tool-calling)

Source coverage spans test planning, web/API/mobile application security, adversary behavior, countermeasures, incident response, OT, cloud, containers, AI, payments, and model tool calling. The skills are original assessment playbooks; keep product-specific implementation aligned to current vendor documentation.

## Synthesis behind the skill taxonomy

- **Engagement first.** NIST SP 800-115 frames testing as planning, execution and analysis/reporting. The package puts scope, ownership, rate, stop conditions, evidence and reporting before active assessment.
- **Applications have several layers.** OWASP WSTG describes test techniques; ASVS describes verifiable application controls. The API Top 10 and MASVS identify distinct API and mobile concerns. The pack therefore separates HTTP/browser behavior, authentication, API authorization, business logic, Android, iOS and code review. A vulnerability name is never treated as proof without a controlled observation.
- **Offense and defense connect through evidence.** ATT&CK provides a behavior vocabulary for controlled emulation and hunting. D3FEND represents countermeasures. NIST SP 800-61 Rev. 3 covers response across the risk management lifecycle. The pack treats simulation as an opportunity to measure detection and response, and includes negative results and false-positive review.
- **Cloud implementations differ.** AWS, Microsoft, Google Cloud and Kubernetes publish service-specific security guidance. The pack distinguishes effective permissions and boundary controls for each platform rather than assuming one generic cloud configuration. Settings and defaults can change; verify current provider documentation at assessment time.
- **Software and AI supply chains matter.** NIST SSDF informs source, build and release controls. MITRE ATLAS and OWASP GenAI material inform model, data, retrieval and agent-tool trust boundaries. Model output remains a proposal; the host application enforces tool permissions.
- **Safety and business context change methods.** NIST's OT guidance emphasizes reliability and safety. Payment assessment uses sandbox data and refers to PCI SSC materials. Physical, RF and OT skills use operator approval and offline or passive evidence by default.

## Scope and limitations

The 1,008 entries are practical task-specific starting playbooks, not a certification, an exhaustive index of every CVE or product, or a substitute for experience. The source anchors cover families of controls; a skill is not automatically mapped to a numbered requirement. A host integration must provide a trusted engagement scope, approve tool side effects and connect its own OpenRouter/Ollama clients. The package intentionally does not contain live-target automation, exploit payloads or credentials.
