---
name: review-gcp-org-policy
description: "Map organization constraints to folders and projects. Use in google cloud security when examining review gcp org policy in an approved assessment."
---

# Review Gcp Org Policy

## Setup

- Read [the execution contract](../../../CONTRACT.md) and the current engagement scope before dispatching a tool. The allowed impact for this skill is **read-only**; any live mutation, third-party touch or sensitive data access requires explicit method approval.
- Identify the owner, exact asset, environment, approved data source, account and stop signal. If any is missing, work on supplied offline evidence only.
- Source anchor: [Google Cloud security](https://docs.cloud.google.com/architecture/blueprints/security-foundations). Confirm current version and product-specific behavior before interpreting a result.

## Investigation

1. State the testable question: **map organization constraints to folders and projects**. Write the expected control and failure condition separately.
2. Use project/folder-scoped exports and effective IAM review.
3. Inspect the most direct evidence for this specific question, then seek an independent corroboration (for example effective policy versus declaration, source versus runtime log, or two synthetic roles). Limit retrieval to the named asset and time window.
4. Check benign explanations: rollout state, inherited policies, environment drift, cache delays, synthetic account setup and version differences. Label ambiguous evidence `unverified`; do not turn a possibility into a confirmed finding.
5. For a verified gap, specify the responsible control owner, fix acceptance criterion and minimum safe retest. Stop if proving more would exceed the engagement scope.

## Result

- Produce a **org policy inheritance map** with UTC timestamp, scope reference, asset, source and tool, expected/observed behavior, a redacted evidence pointer, confidence, impact observed, impact only hypothesized, mitigation and retest.
- Do not include customer data, credentials, real exploit payloads or unnecessary copies of sensitive evidence.
