---
name: review-zone-transfer-policy
description: "Inspect AXFR access to approved secondary servers. Use in dns and edge security when examining review zone transfer policy in an approved assessment."
---

# Review Zone Transfer Policy

## Setup

- Read [the execution contract](../../../CONTRACT.md) and the current engagement scope before dispatching a tool. The allowed impact for this skill is **read-only**; any live mutation, third-party touch or sensitive data access requires explicit method approval.
- Identify the owner, exact asset, environment, approved data source, account and stop signal. If any is missing, work on supplied offline evidence only.
- Source anchor: [DNS and edge security](https://owasp.org/www-project-web-security-testing-guide/stable/). Confirm current version and product-specific behavior before interpreting a result.

## Investigation

1. State the testable question: **inspect AXFR access to approved secondary servers**. Write the expected control and failure condition separately.
2. Compare registrar, DNS, CDN and origin settings across trust boundaries.
3. Inspect the most direct evidence for this specific question, then seek an independent corroboration (for example effective policy versus declaration, source versus runtime log, or two synthetic roles). Limit retrieval to the named asset and time window.
4. Check benign explanations: rollout state, inherited policies, environment drift, cache delays, synthetic account setup and version differences. Label ambiguous evidence `unverified`; do not turn a possibility into a confirmed finding.
5. For a verified gap, specify the responsible control owner, fix acceptance criterion and minimum safe retest. Stop if proving more would exceed the engagement scope.

## Result

- Produce a **zone transfer matrix** with UTC timestamp, scope reference, asset, source and tool, expected/observed behavior, a redacted evidence pointer, confidence, impact observed, impact only hypothesized, mitigation and retest.
- Do not include customer data, credentials, real exploit payloads or unnecessary copies of sensitive evidence.
