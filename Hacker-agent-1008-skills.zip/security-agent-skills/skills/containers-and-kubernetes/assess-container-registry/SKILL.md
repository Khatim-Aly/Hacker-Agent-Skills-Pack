---
name: assess-container-registry
description: "Review registry access, immutability and scanning. Use for workload security review when the authorized task concerns assess container registry."
---

# Assess Container Registry

## Preconditions

- Load `../../../CONTRACT.md` and the engagement scope before any tool call. Stop when target, time, method, identity or impact is outside approval.
- Impact class: **read-only**. If the action changes live state, touches a third party, accesses a real user's data or increases volume, obtain specific owner approval before that action.

## Method

1. Define the question: **review registry access, immutability and scanning**. Name the asset, owner, environment and expected behavior.
2. Use image metadata, manifests and approved cluster read access to compare intended isolation with effective grants.
3. Compare at least two independent signals where possible (configuration and logs, code and behavior, or two role views). Keep requests and data collection to the minimum needed.
4. Record the exact observation, a benign reproduction or configuration path, a plausible counterexample, and uncertainty. Separate verified behavior from a hypothetical attack path.
5. Identify a concrete fix or next check, owner, rollback consideration, and retest criterion. Stop if a meaningful verification would exceed the approved scope.

## Evidence and output

- Produce: **registry control finding**. Include time in UTC, scoped asset, inputs, tool/source, relevant redacted observations, expected result, actual result, confidence and follow-up.
- Avoid live secrets, private records, harmful payloads and broad enumeration in the output. Reference evidence securely instead of embedding it.

## Reference

- [Publisher reference](https://kubernetes.io/docs/concepts/security/pod-security-admission/); use current documentation for exact control behavior. See [research anchors](../../../RESEARCH.md).
