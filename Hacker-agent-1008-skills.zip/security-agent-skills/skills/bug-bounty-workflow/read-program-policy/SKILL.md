---
name: read-program-policy
description: "Extract in-scope assets, forbidden methods and submission requirements. Use for bug bounty research when the authorized task concerns read program policy."
---

# Read Program Policy

## Preconditions

- Load `../../../CONTRACT.md` and the engagement scope before any tool call. Stop when target, time, method, identity or impact is outside approval.
- Impact class: **low-impact**. If the action changes live state, touches a third party, accesses a real user's data or increases volume, obtain specific owner approval before that action.

## Method

1. Define the question: **extract in-scope assets, forbidden methods and submission requirements**. Name the asset, owner, environment and expected behavior.
2. Apply the exact program policy to owner-controlled test accounts and minimal demonstrations.
3. Compare at least two independent signals where possible (configuration and logs, code and behavior, or two role views). Keep requests and data collection to the minimum needed.
4. Record the exact observation, a benign reproduction or configuration path, a plausible counterexample, and uncertainty. Separate verified behavior from a hypothetical attack path.
5. Identify a concrete fix or next check, owner, rollback consideration, and retest criterion. Stop if a meaningful verification would exceed the approved scope.

## Evidence and output

- Produce: **program policy matrix**. Include time in UTC, scoped asset, inputs, tool/source, relevant redacted observations, expected result, actual result, confidence and follow-up.
- Avoid live secrets, private records, harmful payloads and broad enumeration in the output. Reference evidence securely instead of embedding it.

## Reference

- [Publisher reference](https://csrc.nist.gov/pubs/sp/800/115/final); use current documentation for exact control behavior. See [research anchors](../../../RESEARCH.md).
