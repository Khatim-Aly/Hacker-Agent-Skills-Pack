---
name: assess-inbound-attachment-controls
description: "Review file type, scanning and sandbox decisions. Use in email defense when examining assess inbound attachment controls in an approved assessment."
---

# Assess Inbound Attachment Controls

## Setup

- Read [the execution contract](../../../CONTRACT.md) and the current engagement scope before dispatching a tool. The allowed impact for this skill is **read-only**; any live mutation, third-party touch or sensitive data access requires explicit method approval.
- Identify the owner, exact asset, environment, approved data source, account and stop signal. If any is missing, work on supplied offline evidence only.
- Source anchor: [Email defense](https://www.cisecurity.org/controls/v8-1). Confirm current version and product-specific behavior before interpreting a result.

## Investigation

1. State the testable question: **review file type, scanning and sandbox decisions**. Write the expected control and failure condition separately.
2. Compare mail identity, tenant settings and response workflow with owner-provided records.
3. Inspect the most direct evidence for this specific question, then seek an independent corroboration (for example effective policy versus declaration, source versus runtime log, or two synthetic roles). Limit retrieval to the named asset and time window.
4. Check benign explanations: rollout state, inherited policies, environment drift, cache delays, synthetic account setup and version differences. Label ambiguous evidence `unverified`; do not turn a possibility into a confirmed finding.
5. For a verified gap, specify the responsible control owner, fix acceptance criterion and minimum safe retest. Stop if proving more would exceed the engagement scope.

## Result

- Produce a **attachment control note** with UTC timestamp, scope reference, asset, source and tool, expected/observed behavior, a redacted evidence pointer, confidence, impact observed, impact only hypothesized, mitigation and retest.
- Do not include customer data, credentials, real exploit payloads or unnecessary copies of sensitive evidence.
